import React from 'react'

const Navbar = () => {
    return (
        <nav className='w-full flex justify-between items-center bg-slate-700 text-white px-8 py-0 fixed top-0 left-0'>
            <div className="logo">
                <span className='font-bold text-xl'>iTask</span>
            </div>
            <ul className='flex gap-8'>
                <li className='cursor-pointer hover:font-bold transition-all duration-1000'>Home</li>
                <li className='cursor-pointer hover:font-bold transition-all duration-1000'>Your tasks</li> 
            </ul>
        </nav>
    )
}

export default Navbar
