import React, { useState } from 'react'

const TodoList = () => {
    const [todos, setTodos] = useState([])
    const [input, setInput] = useState('')
    const [editIndex, setEditIndex] = useState(null)
    const [editText, setEditText] = useState('')

    const handleAddTodo = () => {
        if (input.trim()) {
            const now = new Date()
            const timestamp = `${now.toLocaleDateString()} ${now.toLocaleTimeString()}`
            setTodos([...todos, { text: input, timestamp, done: false }])
            setInput('')
        }
    }

    const handleClearTodos = () => {
        setTodos([])
    }

    const handleInputChange = (e) => {
        setInput(e.target.value)
    }

    const handleDeleteTodo = (index) => {
        setTodos(todos.filter((_, i) => i !== index))
    }

    const handleToggleDone = (index) => {
        setTodos(todos.map((todo, i) => 
            i === index ? { ...todo, done: !todo.done } : todo
        ))
    }

    const handleEditChange = (e) => {
        setEditText(e.target.value)
    }

    const handleEditTodo = (index) => {
        setEditIndex(index)
        setEditText(todos[index].text)
    }

    const handleSaveEdit = () => {
        if (editText.trim()) {
            setTodos(todos.map((todo, i) => 
                i === editIndex ? { ...todo, text: editText } : todo
            ))
            setEditIndex(null)
            setEditText('')
        }
    }

    return (
        <div className='p-4'>
            <h2 className='text-xl font-bold mb-4'>To-Do List</h2>
            <div className='flex mb-4'>
                <input
                    type='text'
                    value={input}
                    onChange={handleInputChange}
                    className='border rounded p-2 mr-2 flex-1'
                    placeholder='Add a new task'
                />
                <button
                    onClick={handleAddTodo}
                    className='bg-blue-500 text-white rounded p-2'
                >
                    Add
                </button>
            </div>
            <button
                onClick={handleClearTodos}
                className='bg-red-500 text-white rounded p-2 mb-4'
            >
                Clear Tasks
            </button>
            <ul className='list-none pl-0'>
                {todos.map((todo, index) => (
                    <li key={index} className={`flex items-center mb-2 ${todo.done ? 'bg-green-100' : ''}`}>
                        <div className='w-1/4 text-gray-500 text-sm'>{todo.timestamp}</div>
                        <div className={`flex-1 ${todo.done ? 'line-through text-gray-500' : ''}`}>{todo.text}</div>
                        <button
                            onClick={() => handleToggleDone(index)}
                            className='bg-yellow-500 text-white rounded p-1 ml-2'
                        >
                            {todo.done ? 'Undo' : 'Done'}
                        </button>
                        <button
                            onClick={() => handleEditTodo(index)}
                            className='bg-blue-500 text-white rounded p-1 ml-2'
                        >
                            Edit
                        </button>
                        <button
                            onClick={() => handleDeleteTodo(index)}
                            className='bg-red-500 text-white rounded p-1 ml-2'
                        >
                            Delete
                        </button>
                    </li>
                ))}
            </ul>
            {editIndex !== null && (
                <div className='flex items-center mt-4'>
                    <input
                        type='text'
                        value={editText}
                        onChange={handleEditChange}
                        className='border rounded p-2 flex-1'
                        placeholder='Edit task'
                    />
                    <button
                        onClick={handleSaveEdit}
                        className='bg-green-500 text-white rounded p-2 ml-2'
                    >
                        Save
                    </button>
                    <button
                        onClick={() => setEditIndex(null)}
                        className='bg-gray-500 text-white rounded p-2 ml-2'
                    >
                        Cancel
                    </button>
                </div>
            )}
        </div>
    )
}

export default TodoList
